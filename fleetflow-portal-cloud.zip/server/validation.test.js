import { describe, expect, it } from 'vitest';
import { recordSchema, vehicleSchema } from './validation.js';
describe('fleet validation', () => {
    it('rejects a movement whose odometer goes backwards', () => {
        const result = recordSchema.safeParse({ type: 'movement', record_date: '2026-08-31', title: 'Trip', start_km: 1200, end_km: 1100, amount: 0 });
        expect(result.success).toBe(false);
    });
    it('calculates only after accepting positive fuel volume', () => {
        expect(recordSchema.safeParse({ type: 'fuel', record_date: '2026-08-31', title: 'Fuel', quantity: 0, rate: 280, amount: 0 }).success).toBe(false);
        expect(recordSchema.safeParse({ type: 'fuel', record_date: '2026-08-31', title: 'Fuel', quantity: 20, rate: 280, amount: 0 }).success).toBe(true);
    });
    it('accepts a valid minimum vehicle file', () => {
        expect(vehicleSchema.safeParse({ vehicle_id: 'CAR-01', registration_number: 'ABC-123', make: 'Toyota', model: 'Corolla', current_km: 0, status: 'active' }).success).toBe(true);
    });
});
