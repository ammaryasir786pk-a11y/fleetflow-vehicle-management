import { defaultRolePermissions } from './permissions.js';
export async function runMigrations(db) {
    if (!(await db.schema.hasTable('users')))
        await db.schema.createTable('users', t => {
            t.increments('id').primary();
            t.string('name', 120).notNullable();
            t.string('email', 180).notNullable().unique();
            t.string('password_hash', 255).notNullable();
            t.string('role', 40).notNullable().defaultTo('viewer');
            t.boolean('active').notNullable().defaultTo(true);
            t.timestamps(true, true);
        });
    if (!(await db.schema.hasTable('drivers')))
        await db.schema.createTable('drivers', t => {
            t.increments('id').primary();
            t.string('name', 120).notNullable();
            t.string('phone', 40);
            t.string('license_number', 80).unique();
            t.date('license_expiry');
            t.string('status', 30).notNullable().defaultTo('active');
            t.text('notes');
            t.timestamps(true, true);
        });
    const demoDriverPhones = [
        ['Adeel Akhtar', 'DEMO-PK-DRV-009', '+92 300 000 1009'],
        ['Bilal Hussain', 'DEMO-PK-DRV-005', '+92 300 000 1005'],
        ['Faizan Mohsin', 'DEMO-PK-DRV-001', '+92 300 000 1001'],
        ['Hassan Raza', 'DEMO-PK-DRV-007', '+92 300 000 1007'],
        ['Imran Shahid', 'DEMO-PK-DRV-008', '+92 300 000 1008'],
        ['Munawar Ali', 'DEMO-PK-DRV-002', '+92 300 000 1002'],
        ['Sajid Mehmood', 'DEMO-PK-DRV-010', '+92 300 000 1010'],
        ['Tanveer Arif', 'DEMO-PK-DRV-003', '+92 300 000 1003'],
        ['Usman Tariq', 'DEMO-PK-DRV-006', '+92 300 000 1006'],
        ['Zohaib Ahmed', 'DEMO-PK-DRV-004', '+92 300 000 1004'],
    ];
    for (const [name, license_number, phone] of demoDriverPhones)
        await db('drivers').where({ name, license_number }).where(query => query.whereNull('phone').orWhere('phone', '')).update({ phone });
    if (!(await db.schema.hasTable('vehicles')))
        await db.schema.createTable('vehicles', t => {
            t.increments('id').primary();
            t.string('vehicle_id', 80).notNullable().unique();
            t.string('registration_number', 80).notNullable().unique();
            t.string('make', 100).notNullable();
            t.string('model', 100).notNullable();
            t.string('variant', 100);
            t.integer('model_year');
            t.string('color', 60);
            t.string('vehicle_type', 60);
            t.string('fuel_type', 40);
            t.string('transmission', 40);
            t.integer('engine_cc');
            t.string('engine_number', 120);
            t.string('vin', 120).unique();
            t.integer('seating_capacity');
            t.integer('current_km').notNullable().defaultTo(0);
            t.integer('assigned_driver_id').references('id').inTable('drivers').onDelete('SET NULL');
            t.string('status', 30).notNullable().defaultTo('active');
            t.text('notes');
            t.date('registration_date');
            t.string('registration_city', 100);
            t.string('registration_owner', 150);
            t.date('token_tax_expiry');
            t.string('insurance_company', 150);
            t.string('insurance_policy_number', 120);
            t.date('insurance_expiry');
            t.date('fitness_expiry');
            t.date('route_permit_expiry');
            t.date('purchase_date');
            t.string('dealer', 150);
            t.decimal('purchase_price', 14, 2);
            t.string('engine_oil_type', 80);
            t.decimal('oil_capacity', 8, 2);
            t.string('tyre_size', 80);
            t.string('tyre_brand', 100);
            t.integer('last_service_km');
            t.integer('next_service_km');
            t.date('next_service_date');
            t.integer('last_oil_change_km');
            t.integer('next_oil_change_km');
            t.date('next_oil_change_date');
            t.timestamps(true, true);
            t.index(['status'], 'idx_vehicles_status');
        });
    if (!(await db.schema.hasTable('driver_assignments')))
        await db.schema.createTable('driver_assignments', t => {
            t.increments('id').primary();
            t.integer('vehicle_id').notNullable().references('id').inTable('vehicles').onDelete('CASCADE');
            t.integer('driver_id').notNullable().references('id').inTable('drivers').onDelete('RESTRICT');
            t.date('start_date').notNullable();
            t.date('end_date');
            t.string('status', 30).notNullable().defaultTo('active');
            t.text('notes');
            t.timestamps(true, true);
            t.index(['vehicle_id', 'start_date'], 'idx_assignments_vehicle_date');
        });
    if (!(await db.schema.hasTable('records')))
        await db.schema.createTable('records', t => {
            t.increments('id').primary();
            t.integer('vehicle_id').notNullable().references('id').inTable('vehicles').onDelete('CASCADE');
            t.string('type', 30).notNullable();
            t.date('record_date').notNullable();
            t.integer('driver_id').references('id').inTable('drivers').onDelete('SET NULL');
            t.integer('odometer_km');
            t.decimal('quantity', 14, 3);
            t.decimal('rate', 14, 2);
            t.decimal('amount', 14, 2).notNullable().defaultTo(0);
            t.decimal('parts_cost', 14, 2).defaultTo(0);
            t.decimal('labour_cost', 14, 2).defaultTo(0);
            t.integer('start_km');
            t.integer('end_km');
            t.string('category', 80);
            t.string('title', 180);
            t.text('description');
            t.string('vendor', 180);
            t.string('location_from', 180);
            t.string('location_to', 180);
            t.string('reference_number', 120);
            t.string('payment_method', 60);
            t.integer('next_due_km');
            t.date('next_due_date');
            t.text('notes');
            t.integer('created_by').references('id').inTable('users').onDelete('SET NULL');
            t.timestamps(true, true);
            t.index(['vehicle_id', 'record_date'], 'idx_records_vehicle_date');
            t.index(['type', 'record_date'], 'idx_records_type_date');
        });
    if (!(await db.schema.hasTable('attachments')))
        await db.schema.createTable('attachments', t => {
            t.increments('id').primary();
            t.integer('vehicle_id').references('id').inTable('vehicles').onDelete('CASCADE');
            t.integer('record_id').references('id').inTable('records').onDelete('CASCADE');
            t.string('document_type', 80);
            t.string('caption', 180);
            t.string('original_name', 255).notNullable();
            t.string('stored_name', 255).notNullable().unique();
            t.string('mime_type', 100).notNullable();
            t.bigInteger('size').notNullable();
            t.date('expiry_date');
            t.integer('uploaded_by').references('id').inTable('users').onDelete('SET NULL');
            t.timestamps(true, true);
            t.index(['vehicle_id', 'expiry_date'], 'idx_attachments_vehicle_expiry');
        });
    if (!(await db.schema.hasTable('attachment_blobs')))
        await db.schema.createTable('attachment_blobs', t => {
            t.string('stored_name', 255).primary();
            t.binary('content').notNullable();
            t.timestamp('created_at').notNullable().defaultTo(db.fn.now());
        });
    if (!(await db.schema.hasTable('audit_logs')))
        await db.schema.createTable('audit_logs', t => {
            t.increments('id').primary();
            t.integer('user_id').references('id').inTable('users').onDelete('SET NULL');
            t.string('action', 60).notNullable();
            t.string('entity', 60).notNullable();
            t.string('entity_id', 80);
            t.text('metadata');
            t.string('ip', 80);
            t.timestamp('created_at').notNullable().defaultTo(db.fn.now());
            t.index(['created_at'], 'idx_audit_created_at');
            t.index(['entity', 'entity_id'], 'idx_audit_entity');
        });
    if (!(await db.schema.hasTable('settings')))
        await db.schema.createTable('settings', t => {
            t.string('key', 120).primary();
            t.text('value');
            t.timestamps(true, true);
        });
    if (!(await db.schema.hasTable('role_permissions')))
        await db.schema.createTable('role_permissions', t => {
            t.increments('id').primary();
            t.string('role', 40).notNullable();
            t.string('permission', 80).notNullable();
            t.boolean('allowed').notNullable().defaultTo(true);
            t.unique(['role', 'permission'], { indexName: 'uq_role_permission' });
        });
    if (!(await db.schema.hasTable('user_permissions')))
        await db.schema.createTable('user_permissions', t => {
            t.increments('id').primary();
            t.integer('user_id').notNullable().references('id').inTable('users').onDelete('CASCADE');
            t.string('permission', 80).notNullable();
            t.boolean('allowed').notNullable();
            t.unique(['user_id', 'permission'], { indexName: 'uq_user_permission' });
        });
    // Apply dashboard sample values once. After initialization, user edits to
    // these demo rows are preserved across future server restarts.
    if (!(await db('settings').where({ key: 'demo_dashboard_samples_v1' }).first())) {
        await db('vehicles').where({ vehicle_id: 'FF-DEMO-007', registration_number: 'DEMO-MUL-007' }).update({ status: 'maintenance' });
        const expiringDemoDate = new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10);
        await db('vehicles').where({ vehicle_id: 'FF-DEMO-010', registration_number: 'DEMO-ISB-010' }).update({ insurance_expiry: expiringDemoDate });
        await db('settings').insert({ key: 'demo_dashboard_samples_v1', value: 'initialized' }).onConflict('key').ignore();
    }
    for (const [role, permissions] of Object.entries(defaultRolePermissions)) {
        if (permissions.length)
            await db('role_permissions').insert(permissions.map(permission => ({ role, permission, allowed: true }))).onConflict(['role', 'permission']).ignore();
    }
    for (const table of ['users', 'drivers', 'vehicles', 'driver_assignments', 'records', 'attachments', 'audit_logs', 'settings', 'role_permissions', 'user_permissions'])
        await db.raw('ALTER TABLE ?? ENABLE ROW LEVEL SECURITY', [table]);
}
