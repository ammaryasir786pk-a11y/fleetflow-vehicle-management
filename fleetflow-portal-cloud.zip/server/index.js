import { app } from './app.js';
import { config } from './config.js';
import { db, pingDatabase } from './db.js';
import { runMigrations } from './migrations.js';
import { seedDatabase } from './seed.js';
try {
    await pingDatabase();
    await runMigrations(db);
    if (config.nodeEnv !== 'production')
        await seedDatabase(db);
    app.listen(config.port, () => console.log(`FleetFlow API ready at http://localhost:${config.port} (${config.provider})`));
}
catch (error) {
    console.error('FleetFlow could not start because the database is unavailable:', error);
    await db.destroy();
    process.exit(1);
}
