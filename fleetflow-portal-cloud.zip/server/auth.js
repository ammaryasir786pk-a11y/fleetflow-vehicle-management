import jwt from 'jsonwebtoken';
import { config } from './config.js';
import { db } from './db.js';
import { permissionsFor } from './permissions.js';
export function signSession(user) { return jwt.sign(user, config.jwtSecret, { expiresIn: '12h', issuer: 'fleetflow' }); }
export function requireAuth(req, res, next) {
    const token = req.cookies?.fleet_session || req.headers.authorization?.replace(/^Bearer /, '');
    if (!token)
        return res.status(401).json({ error: 'Authentication required.' });
    try {
        req.user = jwt.verify(token, config.jwtSecret, { issuer: 'fleetflow' });
        next();
    }
    catch {
        res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
    }
}
const rank = { viewer: 1, data_entry: 2, accountant: 3, fleet_manager: 3, manager: 4, admin: 5, super_admin: 6 };
export function requireRole(minimum) {
    return (req, res, next) => {
        if (!req.user || rank[req.user.role] < rank[minimum])
            return res.status(403).json({ error: 'You do not have permission for this action.' });
        next();
    };
}
export function requirePermission(permission) {
    return async (req, res, next) => {
        try {
            if (!req.user)
                return res.status(401).json({ error: 'Authentication required.' });
            const current = await db('users').where({ id: req.user.id, active: true }).first('role');
            if (!current)
                return res.status(401).json({ error: 'This account is inactive.' });
            const allowed = await permissionsFor(req.user.id, current.role);
            if (!allowed.includes(permission))
                return res.status(403).json({ error: 'Your policy does not allow this action.' });
            next();
        }
        catch (error) {
            next(error);
        }
    };
}
