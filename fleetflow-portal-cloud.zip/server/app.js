import express from 'express';
import bcrypt from 'bcryptjs';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import crypto from 'node:crypto';
import path from 'node:path';
import { z } from 'zod';
import { db } from './db.js';
import { config } from './config.js';
import { requireAuth, requirePermission, signSession } from './auth.js';
import { loginSchema, recordSchema, vehicleSchema } from './validation.js';
import { adminRouter } from './adminRoutes.js';
import { reportRouter } from './reportRoutes.js';
import { permissionsFor } from './permissions.js';
import { attachmentStore } from './supabaseStorage.js';
const expenseRecordTypes = ['fuel', 'repair', 'maintenance', 'oil_change', 'expense', 'goods'];
const localDate = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
const localDateAfter = (days) => { const date = new Date(); date.setDate(date.getDate() + days); return localDate(date); };
const app = express();
app.set('trust proxy', 1);
app.use(helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    contentSecurityPolicy: {
        directives: {
            ...helmet.contentSecurityPolicy.getDefaultDirectives(),
            'img-src': ["'self'", 'data:', 'blob:', 'https://images.unsplash.com'],
        },
    },
}));
app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());
async function audit(userId, action, entity, entityId, req, metadata) {
    await db('audit_logs').insert({ user_id: userId, action, entity, entity_id: entityId == null ? null : String(entityId), ip: req.ip, metadata: metadata ? JSON.stringify(metadata) : null });
}
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const parseId = (value) => { const id = Number(Array.isArray(value) ? value[0] : value); if (!Number.isInteger(id) || id < 1)
    throw Object.assign(new Error('Invalid record id.'), { status: 400 }); return id; };
async function addAttachmentsToRecords(rows) {
    if (!rows.length)
        return rows.map(row => ({ ...row, attachments: [] }));
    const files = await db('attachments').whereIn('record_id', rows.map(row => row.id)).orderBy('created_at', 'desc');
    const grouped = new Map();
    for (const file of files)
        grouped.set(Number(file.record_id), [...(grouped.get(Number(file.record_id)) || []), file]);
    return rows.map(row => ({ ...row, attachments: grouped.get(Number(row.id)) || [] }));
}
async function addPhotosToVehicles(rows) {
    if (!rows.length)
        return rows;
    const photos = await db('attachments').whereIn('vehicle_id', rows.map(row => row.id)).where('document_type', 'Vehicle Photo').whereLike('mime_type', 'image/%').orderBy('created_at', 'desc');
    const latest = new Map();
    for (const photo of photos)
        if (!latest.has(Number(photo.vehicle_id)))
            latest.set(Number(photo.vehicle_id), photo);
    return rows.map(row => ({ ...row, photo: latest.get(Number(row.id)) || null }));
}
app.get('/api/health', wrap(async (_req, res) => { await db.raw('select 1'); res.json({ ok: true, database: config.provider }); }));
app.get('/api/auth/setup-needed', wrap(async (_req, res) => {
    const [{ count }] = await db('users').count({ count: '*' });
    res.json({ needed: Number(count) === 0 });
}));
app.post('/api/auth/initial-admin', rateLimit({ windowMs: 15 * 60_000, limit: 3, standardHeaders: 'draft-7', legacyHeaders: false }), wrap(async (req, res) => {
    const expected = Buffer.from(String(process.env.BOOTSTRAP_TOKEN || ''));
    const supplied = Buffer.from(String(req.get('x-bootstrap-token') || ''));
    if (expected.length < 32 || supplied.length !== expected.length || !crypto.timingSafeEqual(supplied, expected))
        return res.status(403).json({ error: 'The initial setup key is invalid.' });
    const input = z.object({ name: z.string().trim().min(2).max(120), email: z.string().email().transform(v => v.toLowerCase()), password: z.string().min(12).max(200) }).parse(req.body);
    const passwordHash = await bcrypt.hash(input.password, 12);
    const nonce = crypto.randomUUID();
    const user = await db.transaction(async trx => {
        await trx('settings').insert({ key: 'initial_admin_claim', value: nonce }).onConflict('key').ignore();
        const claim = await trx('settings').where({ key: 'initial_admin_claim', value: nonce }).first();
        if (!claim || Number((await trx('users').count({ count: '*' }).first()).count) !== 0)
            return null;
        const [created] = await trx('users').insert({ name: input.name, email: input.email, password_hash: passwordHash, role: 'super_admin', active: true }).returning(['id', 'name', 'email', 'role', 'active']);
        return created;
    });
    if (!user)
        return res.status(409).json({ error: 'Initial setup has already been completed.' });
    await audit(user.id, 'initial_setup', 'user', user.id, req);
    res.status(201).json({ message: 'Administrator account created. Sign in with your email and password.' });
}));
app.post('/api/auth/login', rateLimit({ windowMs: 15 * 60_000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false }), wrap(async (req, res) => {
    const input = loginSchema.parse(req.body);
    const user = await db('users').where({ email: input.email.toLowerCase(), active: true }).first();
    if (!user || !(await bcrypt.compare(input.password, user.password_hash)))
        return res.status(401).json({ error: 'Email or password is incorrect.' });
    const safe = { id: user.id, name: user.name, email: user.email, role: user.role, permissions: await permissionsFor(user.id, user.role) };
    res.cookie('fleet_session', signSession(safe), { httpOnly: true, sameSite: 'lax', secure: config.cookieSecure, maxAge: 12 * 3600_000, path: '/' });
    await audit(user.id, 'login', 'session', undefined, req);
    res.json({ user: safe });
}));
app.post('/api/auth/logout', requireAuth, wrap(async (req, res) => { await audit(req.user?.id, 'logout', 'session', undefined, req); res.clearCookie('fleet_session'); res.status(204).end(); }));
app.post('/api/auth/change-password', requireAuth, wrap(async (req, res) => {
    const currentPassword = req.body?.currentPassword, newPassword = req.body?.newPassword;
    if (typeof currentPassword !== 'string' || typeof newPassword !== 'string' || newPassword.length < 12 || newPassword.length > 200)
        return res.status(400).json({ error: 'Enter your current password and a new password between 12 and 200 characters.' });
    const user = await db('users').where({ id: req.user.id, active: true }).first('id', 'password_hash');
    if (!user || !(await bcrypt.compare(currentPassword, user.password_hash)))
        return res.status(400).json({ error: 'Current password is incorrect.' });
    await db('users').where({ id: user.id }).update({ password_hash: await bcrypt.hash(newPassword, 12), updated_at: db.fn.now() });
    await audit(user.id, 'change_password', 'user', user.id, req);
    res.json({ message: 'Password changed successfully.' });
}));
app.get('/api/auth/me', requireAuth, wrap(async (req, res) => { const current = await db('users').where({ id: req.user.id, active: true }).first('id', 'name', 'email', 'role'); if (!current)
    return res.status(401).json({ error: 'This account is inactive.' }); res.json({ user: { ...current, permissions: await permissionsFor(current.id, current.role) } }); }));
app.get('/api/dashboard', requireAuth, requirePermission('view_dashboard'), wrap(async (_req, res) => {
    const currentDay = localDate(), currentMonth = `${currentDay.slice(0, 7)}-01`, soon = localDateAfter(30);
    const [vehicleCounts, driverCount, todayMovement, vehiclesOnTrip, todayFuel, todayCosts, monthlyCosts, monthlyRevenue, expiringAttachments, vehicleExpiryDates] = await Promise.all([
        db('vehicles').select('status').count('* as count').groupBy('status'), db('drivers').where({ status: 'active' }).count('* as count').first(),
        db('records').where({ type: 'movement', record_date: currentDay }).count('* as count').first(),
        db('records').where({ type: 'movement', record_date: currentDay }).countDistinct('vehicle_id as count').first(),
        db('records').where({ type: 'fuel', record_date: currentDay }).sum('amount as total').first(),
        db('records').where({ record_date: currentDay }).whereIn('type', expenseRecordTypes).whereNot(b => b.whereILike('category', '%revenue%').orWhereILike('category', '%income%').orWhereILike('title', '%revenue%').orWhereILike('title', '%income%')).sum('amount as total').first(),
        db('records').where('record_date', '>=', currentMonth).whereIn('type', expenseRecordTypes).whereNot(b => b.whereILike('category', '%revenue%').orWhereILike('category', '%income%').orWhereILike('title', '%revenue%').orWhereILike('title', '%income%')).sum('amount as total').first(),
        db('records').where('record_date', '>=', currentMonth).where(b => b.whereILike('category', '%revenue%').orWhereILike('category', '%income%').orWhereILike('title', '%revenue%').orWhereILike('title', '%income%')).sum('amount as total').first(),
        db('attachments').whereBetween('expiry_date', [currentDay, soon]).count('* as count').first(),
        db('vehicles').select('insurance_expiry', 'token_tax_expiry', 'fitness_expiry', 'route_permit_expiry'),
    ]);
    const byType = await db('records').select('type').sum('amount as total').where('record_date', '>=', new Date(Date.now() - 180 * 86400000).toISOString().slice(0, 10)).groupBy('type');
    const recent = await db('records as r').leftJoin('vehicles as v', 'v.id', 'r.vehicle_id').select('r.*', 'v.vehicle_id as vehicle_code', 'v.make', 'v.model').orderBy('r.record_date', 'desc').limit(8);
    const count = (s) => Number(vehicleCounts.find(v => v.status === s)?.count || 0);
    const totalVehicles = vehicleCounts.reduce((a, v) => a + Number(v.count), 0);
    const revenue = Number(monthlyRevenue?.total || 0), expenses = Number(monthlyCosts?.total || 0);
    const vehicleExpiryCount = vehicleExpiryDates.reduce((total, vehicle) => total + ['insurance_expiry', 'token_tax_expiry', 'fitness_expiry', 'route_permit_expiry'].filter(field => vehicle[field] && String(vehicle[field]).slice(0, 10) >= currentDay && String(vehicle[field]).slice(0, 10) <= soon).length, 0);
    res.json({ cards: { totalVehicles, activeVehicles: count('active'), maintenanceVehicles: count('maintenance'), vehiclesOnTrip: Number(vehiclesOnTrip?.count || 0), totalDrivers: Number(driverCount?.count || 0), todayMovement: Number(todayMovement?.count || 0), todayFuelCost: Number(todayFuel?.total || 0), todayExpenses: Number(todayCosts?.total || 0), monthlyRevenue: revenue, monthlyExpenses: expenses, monthlyCost: expenses, netProfitLoss: revenue - expenses, expiringDocuments: Number(expiringAttachments?.count || 0) + vehicleExpiryCount }, byType, recent });
}));
app.get('/api/drivers', requireAuth, requirePermission('view_drivers'), wrap(async (_req, res) => res.json(await db('drivers').orderBy('name'))));
app.post('/api/drivers', requireAuth, requirePermission('manage_drivers'), wrap(async (req, res) => {
    if (!req.body.name?.trim())
        return res.status(400).json({ error: 'Driver name is required.' });
    const [row] = await db('drivers').insert({ name: req.body.name.trim(), phone: req.body.phone || null, license_number: req.body.license_number || null, license_expiry: req.body.license_expiry || null, status: req.body.status || 'active', notes: req.body.notes || null }).returning('*');
    await audit(req.user?.id, 'create', 'driver', row.id, req);
    res.status(201).json(row);
}));
app.get('/api/vehicles', requireAuth, requirePermission('view_vehicles'), wrap(async (req, res) => {
    const q = String(req.query.q || '').trim();
    const query = db('vehicles as v').leftJoin('drivers as d', 'd.id', 'v.assigned_driver_id').select('v.*', 'd.name as assigned_driver').orderBy('v.created_at', 'desc');
    if (q)
        query.where(b => b.whereILike('v.vehicle_id', `%${q}%`).orWhereILike('v.registration_number', `%${q}%`).orWhereILike('v.make', `%${q}%`).orWhereILike('v.model', `%${q}%`));
    res.json(await addPhotosToVehicles(await query));
}));
app.post('/api/vehicles', requireAuth, requirePermission('create_vehicle'), wrap(async (req, res) => {
    const input = vehicleSchema.parse(req.body);
    const [row] = await db('vehicles').insert(input).returning('*');
    await audit(req.user?.id, 'create', 'vehicle', row.id, req);
    res.status(201).json(row);
}));
app.get('/api/vehicles/:id', requireAuth, requirePermission('view_vehicles'), wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const vehicle = await db('vehicles as v').leftJoin('drivers as d', 'd.id', 'v.assigned_driver_id').select('v.*', 'd.name as assigned_driver').where('v.id', id).first();
    if (!vehicle)
        return res.status(404).json({ error: 'Vehicle not found.' });
    const records = await addAttachmentsToRecords(await db('records as r').leftJoin('drivers as d', 'd.id', 'r.driver_id').select('r.*', 'd.name as driver_name').where('r.vehicle_id', id).orderBy('record_date', 'desc').orderBy('r.id', 'desc'));
    const attachments = await db('attachments').where({ vehicle_id: id }).orderBy('created_at', 'desc');
    const assignments = await db('driver_assignments as a').join('drivers as d', 'd.id', 'a.driver_id').select('a.*', 'd.name as driver_name').where('a.vehicle_id', id).orderBy('start_date', 'desc');
    const totals = {};
    for (const r of records)
        totals[r.type] = (totals[r.type] || 0) + Number(r.amount || 0);
    const distance = records.filter(r => r.type === 'movement').reduce((a, r) => a + Math.max(0, Number(r.end_km || 0) - Number(r.start_km || 0)), 0);
    const fuelLiters = records.filter(r => r.type === 'fuel').reduce((a, r) => a + Number(r.quantity || 0), 0);
    const totalCost = Object.values(totals).reduce((a, v) => a + v, 0);
    res.json({ vehicle, records, attachments, assignments, summary: { totals, distance, fuelLiters, totalCost } });
}));
app.put('/api/vehicles/:id', requireAuth, requirePermission('edit_vehicle'), wrap(async (req, res) => {
    const id = parseId(req.params.id), input = vehicleSchema.parse(req.body), before = await db('vehicles').where({ id }).first();
    if (!before)
        return res.status(404).json({ error: 'Vehicle not found.' });
    if (Number(input.current_km) < Number(before.current_km))
        return res.status(400).json({ error: 'Current KM cannot go backwards.' });
    const [row] = await db('vehicles').where({ id }).update({ ...input, updated_at: db.fn.now() }).returning('*');
    await audit(req.user?.id, 'update', 'vehicle', id, req, { before, after: row });
    res.json(row);
}));
app.delete('/api/vehicles/:id', requireAuth, requirePermission('delete_vehicle'), wrap(async (req, res) => { const id = parseId(req.params.id); const before = await db('vehicles').where({ id }).first(); if (!before)
    return res.status(404).json({ error: 'Vehicle not found.' }); await db('vehicles').where({ id }).delete(); await audit(req.user?.id, 'delete', 'vehicle', id, req, { before }); res.status(204).end(); }));
app.get('/api/records', requireAuth, requirePermission('view_records'), wrap(async (req, res) => { const query = db('records as r').join('vehicles as v', 'v.id', 'r.vehicle_id').leftJoin('drivers as d', 'd.id', 'r.driver_id').select('r.*', 'v.vehicle_id as vehicle_code', 'v.registration_number', 'v.make', 'v.model', 'd.name as driver_name').orderBy('r.record_date', 'desc').orderBy('r.id', 'desc'); if (req.query.type)
    query.where('r.type', String(req.query.type)); if (req.query.vehicleId)
    query.where('r.vehicle_id', Number(req.query.vehicleId)); res.json(await addAttachmentsToRecords(await query.limit(1000))); }));
app.post('/api/vehicles/:id/records', requireAuth, requirePermission('manage_records'), wrap(async (req, res) => {
    const vehicleId = parseId(req.params.id), vehicle = await db('vehicles').where({ id: vehicleId }).first();
    if (!vehicle)
        return res.status(404).json({ error: 'Vehicle not found.' });
    const input = recordSchema.parse(req.body);
    const maxKm = Math.max(Number(input.odometer_km || 0), Number(input.end_km || 0));
    if (maxKm && maxKm < Number(vehicle.current_km))
        return res.status(400).json({ error: `KM cannot be lower than current vehicle KM (${vehicle.current_km}).` });
    const amount = input.type === 'fuel' && input.quantity && input.rate ? Number(input.quantity) * Number(input.rate) : input.type === 'repair' ? Number(input.parts_cost || 0) + Number(input.labour_cost || 0) : input.amount;
    const [row] = await db('records').insert({ ...input, amount, vehicle_id: vehicleId, created_by: req.user?.id }).returning('*');
    if (maxKm > Number(vehicle.current_km))
        await db('vehicles').where({ id: vehicleId }).update({ current_km: maxKm, updated_at: db.fn.now() });
    await audit(req.user?.id, 'create', input.type, row.id, req);
    res.status(201).json(row);
}));
app.delete('/api/records/:id', requireAuth, requirePermission('delete_records'), wrap(async (req, res) => { const id = parseId(req.params.id), before = await db('records').where({ id }).first(); if (!before)
    return res.status(404).json({ error: 'Record not found.' }); await db('records').where({ id }).delete(); await audit(req.user?.id, 'delete', before.type, id, req, { before }); res.status(204).end(); }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: config.maxUploadBytes }, fileFilter: (_r, f, cb) => cb(null, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'].includes(f.mimetype)) });
app.post('/api/vehicles/:id/attachments', requireAuth, requirePermission('upload_documents'), upload.single('file'), wrap(async (req, res) => {
    const vehicleId = parseId(req.params.id);
    if (!req.file)
        return res.status(400).json({ error: 'A JPG, PNG, WebP or PDF file is required.' });
    const storedName = `${crypto.randomUUID()}${String(req.file.originalname).match(/\.[^.]+$/)?.[0]?.toLowerCase() || ''}`;
    try {
        const vehicle = await db('vehicles').where({ id: vehicleId }).first('id');
        if (!vehicle)
            return res.status(404).json({ error: 'Vehicle not found.' });
        const recordId = req.body.record_id ? parseId(req.body.record_id) : null;
        if (recordId) {
            const record = await db('records').where({ id: recordId, vehicle_id: vehicleId }).first('id');
            if (!record)
                return res.status(400).json({ error: 'The selected record does not belong to this vehicle.' });
        }
        await attachmentStore.put(storedName, req.file.buffer, req.file.mimetype);
        const [row] = await db('attachments').insert({ vehicle_id: vehicleId, record_id: recordId, document_type: req.body.document_type || 'Other', caption: req.body.caption || null, original_name: req.file.originalname, stored_name: storedName, mime_type: req.file.mimetype, size: req.file.size, expiry_date: req.body.expiry_date || null, uploaded_by: req.user?.id }).returning('*');
        await audit(req.user?.id, 'upload', 'attachment', row.id, req);
        res.status(201).json(row);
    }
    catch (error) {
        await attachmentStore.delete(storedName).catch(() => {});
        throw error;
    }
}));
app.get('/api/attachments/:id/file', requireAuth, requirePermission('view_documents'), wrap(async (req, res) => { const row = await db('attachments').where({ id: parseId(req.params.id) }).first(); if (!row)
    return res.status(404).json({ error: 'File not found.' }); const object = await attachmentStore.get(row.stored_name); if (!object)
    return res.status(404).json({ error: 'File content is missing.' }); res.type(row.mime_type); res.setHeader('Content-Disposition', `${req.query.download === '1' ? 'attachment' : 'inline'}; filename*=UTF-8''${encodeURIComponent(row.original_name)}`); res.send(object); }));
app.delete('/api/attachments/:id', requireAuth, requirePermission('delete_documents'), wrap(async (req, res) => { const id = parseId(req.params.id), row = await db('attachments').where({ id }).first(); if (!row)
    return res.status(404).json({ error: 'File not found.' }); await db('attachments').where({ id }).delete(); await attachmentStore.delete(row.stored_name); await audit(req.user?.id, 'delete', 'attachment', id, req); res.status(204).end(); }));
app.get('/api/attachments', requireAuth, requirePermission('view_documents'), wrap(async (req, res) => { const q = db('attachments as a').leftJoin('vehicles as v', 'v.id', 'a.vehicle_id').select('a.*', 'v.vehicle_id as vehicle_code', 'v.registration_number', 'v.make', 'v.model').orderBy('a.created_at', 'desc'); if (req.query.vehicleId)
    q.where('a.vehicle_id', Number(req.query.vehicleId)); res.json(await q.limit(1000)); }));
app.get('/api/notifications', requireAuth, requirePermission('view_dashboard'), wrap(async (_req, res) => {
    const today = localDate(), soon = localDateAfter(30);
    const vehicles = await db('vehicles').select('id', 'vehicle_id', 'make', 'model', 'current_km', 'next_service_km', 'next_service_date', 'next_oil_change_km', 'next_oil_change_date', 'insurance_expiry', 'token_tax_expiry', 'fitness_expiry', 'route_permit_expiry');
    const items = [];
    for (const v of vehicles) {
        for (const [field, label] of [['insurance_expiry', 'Insurance'], ['token_tax_expiry', 'Token tax'], ['fitness_expiry', 'Fitness certificate'], ['route_permit_expiry', 'Route permit']]) {
            if (v[field] && String(v[field]).slice(0, 10) <= soon)
                items.push({ id: `${v.id}-${field}`, vehicleId: v.id, title: `${label} ${String(v[field]).slice(0, 10) < today ? 'expired' : 'expiring soon'}`, detail: `${v.vehicle_id} · ${String(v[field]).slice(0, 10)}`, severity: String(v[field]).slice(0, 10) < today ? 'danger' : 'warning' });
        }
        if ((v.next_service_km && Number(v.current_km) >= Number(v.next_service_km)) || (v.next_service_date && String(v.next_service_date).slice(0, 10) <= soon))
            items.push({ id: `${v.id}-service`, vehicleId: v.id, title: 'Service due', detail: `${v.vehicle_id} · current ${Number(v.current_km).toLocaleString()} KM`, severity: 'warning' });
        if ((v.next_oil_change_km && Number(v.current_km) >= Number(v.next_oil_change_km)) || (v.next_oil_change_date && String(v.next_oil_change_date).slice(0, 10) <= soon))
            items.push({ id: `${v.id}-oil`, vehicleId: v.id, title: 'Oil change due', detail: v.vehicle_id, severity: 'warning' });
    }
    res.json(items);
}));
app.get('/api/reports/expenses.csv', requireAuth, requirePermission('export_reports'), wrap(async (req, res) => {
    const rows = await db('records as r').join('vehicles as v', 'v.id', 'r.vehicle_id').whereIn('r.type', expenseRecordTypes).whereNot(b => b.whereILike('r.category', '%revenue%').orWhereILike('r.category', '%income%').orWhereILike('r.title', '%revenue%').orWhereILike('r.title', '%income%')).select('r.record_date', 'v.vehicle_id', 'v.registration_number', 'r.type', 'r.category', 'r.title', 'r.vendor', 'r.amount').orderBy('r.record_date', 'desc');
    const esc = (v) => `"${String(v ?? '').replaceAll('"', '""')}"`;
    const csv = ['Date,Vehicle ID,Registration,Type,Category,Description,Vendor,Amount', ...rows.map(r => [r.record_date, r.vehicle_id, r.registration_number, r.type, r.category, r.title, r.vendor, r.amount].map(esc).join(','))].join('\r\n');
    await audit(req.user?.id, 'export', 'expense_report', undefined, req);
    res.type('text/csv').setHeader('Content-Disposition', 'attachment; filename="fleet-expenses.csv"').send(csv);
}));
app.get('/api/admin/backup', requireAuth, requirePermission('backup_restore'), wrap(async (req, res) => {
    const tables = ['users', 'drivers', 'vehicles', 'driver_assignments', 'records', 'attachments', 'settings', 'audit_logs', 'role_permissions', 'user_permissions'];
    const data = {};
    for (const table of tables) data[table] = await db(table).select('*');
    const files = {};
    for (const attachment of data.attachments) {
        const object = await attachmentStore.get(attachment.stored_name);
        if (!object) throw Object.assign(new Error(`Uploaded file is missing: ${attachment.original_name}`), { status: 409 });
        files[attachment.stored_name] = object.toString('base64');
    }
    data.uploadedFiles = files;
    await audit(req.user?.id, 'backup', 'database', undefined, req);
    res.setHeader('Content-Disposition', `attachment; filename="fleet-backup-${localDate()}.json"`);
    res.json({ format: 'fleetflow-backup', version: 2, createdAt: new Date().toISOString(), databaseProvider: config.provider, data });
}));
app.get('/api/audit', requireAuth, requirePermission('view_audit'), wrap(async (_req, res) => res.json(await db('audit_logs as a').leftJoin('users as u', 'u.id', 'a.user_id').select('a.*', 'u.name as user_name').orderBy('a.created_at', 'desc').limit(200))));
app.use('/api/reports', requireAuth, reportRouter);
app.use('/api/admin', requireAuth, adminRouter);
app.get('/setup', (_req, res) => res.sendFile(path.join(config.appRoot, 'dist', 'setup.html')));
app.use(express.static(path.join(config.appRoot, 'dist'), { index: false, maxAge: config.nodeEnv === 'production' ? '1h' : 0 }));
app.get('/{*path}', (_req, res) => res.sendFile(path.join(config.appRoot, 'dist', 'index.html')));
const errorHandler = (err, _req, res, _next) => { console.error(err); if (err?.name === 'ZodError')
    return res.status(400).json({ error: 'Please correct the highlighted fields.', issues: err.issues }); if (String(err?.code).includes('SQLITE_CONSTRAINT') || String(err?.code) === '23505')
    return res.status(409).json({ error: 'A record with the same unique value already exists.' }); res.status(err.status || 500).json({ error: config.nodeEnv === 'production' ? 'An unexpected error occurred.' : err.message }); };
app.use(errorHandler);
export { app };
