import { Router } from 'express';
import { db } from './db.js';
import { requirePermission } from './auth.js';
export const reportRouter = Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const cols = (items) => items.map(([key, label, type]) => ({ key, label, type: type || 'text' }));
const today = () => { const date = new Date(); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; };
const monthStart = () => `${today().slice(0, 7)}-01`;
const soon = (days = 30) => { const date = new Date(); date.setDate(date.getDate() + days); return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; };
const day = (value) => value instanceof Date ? value.toISOString().slice(0, 10) : String(value || '').slice(0, 10);
const month = (value) => String(value || '').slice(0, 7);
const sum = (rows, key) => rows.reduce((total, row) => total + Number(row[key] || 0), 0);
const group = (rows, key) => { const result = new Map(); for (const row of rows) {
    const k = key(row) || 'Unspecified';
    result.set(k, [...(result.get(k) || []), row]);
} return result; };
const summaryFor = (rows) => ({ records: rows.length, totalAmount: sum(rows, 'amount'), totalDistance: sum(rows, 'distance'), totalQuantity: sum(rows, 'quantity') });
function applyRecordFilters(query, q) {
    if (q.vehicleId)
        query.where('r.vehicle_id', Number(q.vehicleId));
    if (q.driverId)
        query.where('r.driver_id', Number(q.driverId));
    if (q.from)
        query.where('r.record_date', '>=', String(q.from));
    if (q.to)
        query.where('r.record_date', '<=', String(q.to));
    if (q.category)
        query.whereILike('r.category', `%${String(q.category)}%`);
    if (q.supplier)
        query.whereILike('r.vendor', `%${String(q.supplier)}%`);
    return query;
}
async function records(q, types) {
    const query = applyRecordFilters(db('records as r').join('vehicles as v', 'v.id', 'r.vehicle_id').leftJoin('drivers as d', 'd.id', 'r.driver_id'), q);
    if (types?.length)
        query.whereIn('r.type', types);
    const rows = await query.select('r.*', 'v.vehicle_id as vehicle_code', 'v.registration_number', 'v.make', 'v.model', 'v.current_km', 'd.name as driver_name').orderBy('r.record_date', 'desc').orderBy('r.id', 'desc');
    return rows.map((row) => ({ ...row, distance: row.end_km != null && row.start_km != null ? Math.max(0, Number(row.end_km) - Number(row.start_km)) : 0 }));
}
async function vehicles(q) {
    const query = db('vehicles as v').leftJoin('drivers as d', 'd.id', 'v.assigned_driver_id').select('v.*', 'd.name as assigned_driver').orderBy('v.vehicle_id');
    if (q.vehicleId)
        query.where('v.id', Number(q.vehicleId));
    return query;
}
async function drivers(q) {
    const query = db('drivers').orderBy('name');
    if (q.driverId)
        query.where('id', Number(q.driverId));
    return query;
}
const standardColumns = cols([['record_date', 'Date', 'date'], ['vehicle_code', 'Vehicle'], ['registration_number', 'Registration'], ['driver_name', 'Driver'], ['title', 'Description'], ['category', 'Category'], ['vendor', 'Vendor'], ['odometer_km', 'KM', 'number'], ['amount', 'Amount', 'money']]);
const vehicleColumns = cols([['vehicle_id', 'Vehicle ID'], ['registration_number', 'Registration'], ['make', 'Make'], ['model', 'Model'], ['model_year', 'Year', 'number'], ['status', 'Status'], ['current_km', 'Current KM', 'number'], ['assigned_driver', 'Driver']]);
const driverColumns = cols([['name', 'Driver'], ['phone', 'Phone'], ['license_number', 'License'], ['license_expiry', 'License Expiry', 'date'], ['status', 'Status']]);
const labels = {
    all_vehicles: 'All Vehicles Report', active_vehicles: 'Active / Inactive Vehicles', vehicle_details: 'Vehicle Details Report', vehicle_status: 'Vehicle Status Report', vehicle_performance: 'Vehicle-wise Performance Report', vehicle_utilization: 'Vehicle Utilization Report', mileage: 'Mileage / Kilometer Report', vehicle_cost: 'Vehicle Cost Report', fleet_summary: 'Fleet Summary Report',
    fuel: 'Fuel Transactions Report', fuel_daily: 'Daily Fuel Consumption', fuel_vehicle: 'Vehicle-wise Fuel Report', fuel_cost: 'Fuel Cost Report', fuel_average: 'Average Fuel Consumption', fuel_efficiency: 'Fuel Efficiency (KM per Liter)', fuel_monthly: 'Monthly Fuel Expense Report', fuel_abnormal: 'Fuel Abnormal Consumption Alert Report',
    maintenance: 'Vehicle Maintenance History', service_due: 'Service Due Report', upcoming_maintenance: 'Upcoming Maintenance Report', repair: 'Repair History', repair_cost: 'Repair Cost Report', vehicle_maintenance_cost: 'Vehicle-wise Maintenance Cost', spare_parts: 'Spare Parts Consumption Report', workshop: 'Workshop / Mechanic Report', oil_change: 'Oil Change Report',
    driver_list: 'Driver List Report', driver_attendance: 'Driver Attendance / Trip Activity', driver_performance: 'Driver Performance Report', driver_salary: 'Driver Salary Report', driver_fine: 'Driver Fine / Penalty Report', driver_license_expiry: 'Driver License Expiry Report', driver_expense: 'Driver Expense Report',
    expense: 'Expense Transactions Report', daily_expense: 'Daily Expense Report', vehicle_expense: 'Vehicle-wise Expense Report', fuel_expense: 'Fuel Expense Report', maintenance_expense: 'Maintenance Expense Report', goods: 'Goods / Purchase Movement Report', movement: 'Movement Report',
    dashboard_summary: 'Dashboard Summary Report', document_expiry: 'Document Expiry Report', registration_expiry: 'Vehicle Registration Expiry', insurance_expiry: 'Vehicle Insurance Expiry', fitness_expiry: 'Fitness Certificate Expiry', route_permit_expiry: 'Route Permit Expiry', maintenance_due: 'Maintenance Due Alert', oil_due: 'Oil Change Due Alert', tyre_due: 'Tyre Replacement Due Alert', audit: 'Audit & User Activity Report',
};
reportRouter.get('/catalog', requirePermission('view_reports'), (_req, res) => res.json(Object.entries(labels).map(([key, label]) => ({ key, label }))));
reportRouter.get('/data', requirePermission('view_reports'), wrap(async (req, res) => {
    const type = String(req.query.type || 'all_vehicles');
    let rows = [], columns = [], summary = {};
    if (['fuel', 'movement', 'repair', 'maintenance', 'oil_change', 'expense', 'goods'].includes(type)) {
        rows = await records(req.query, [type]);
        columns = type === 'fuel' ? cols([['record_date', 'Date', 'date'], ['vehicle_code', 'Vehicle'], ['driver_name', 'Driver'], ['odometer_km', 'Odometer', 'number'], ['quantity', 'Liters', 'number'], ['rate', 'Rate/Liter', 'money'], ['amount', 'Fuel Cost', 'money'], ['vendor', 'Fuel Station']]) : type === 'movement' ? cols([['record_date', 'Date', 'date'], ['vehicle_code', 'Vehicle'], ['driver_name', 'Driver'], ['location_from', 'From'], ['location_to', 'To'], ['title', 'Purpose'], ['start_km', 'Start KM', 'number'], ['end_km', 'End KM', 'number'], ['distance', 'Distance', 'number']]) : type === 'repair' ? cols([['record_date', 'Date', 'date'], ['vehicle_code', 'Vehicle'], ['odometer_km', 'KM', 'number'], ['title', 'Problem / Work'], ['parts_cost', 'Parts', 'money'], ['labour_cost', 'Labour', 'money'], ['amount', 'Total', 'money'], ['vendor', 'Workshop']]) : standardColumns;
        summary = summaryFor(rows);
    }
    else if (['all_vehicles', 'vehicle_details', 'active_vehicles', 'vehicle_status', 'fleet_summary'].includes(type)) {
        rows = await vehicles(req.query);
        if (type === 'active_vehicles')
            rows = rows.filter((row) => ['active', 'inactive'].includes(row.status));
        columns = vehicleColumns;
        summary = { vehicles: rows.length, active: rows.filter((row) => row.status === 'active').length, inactive: rows.filter((row) => row.status === 'inactive').length, maintenance: rows.filter((row) => row.status === 'maintenance').length, totalKm: sum(rows, 'current_km') };
    }
    else if (['vehicle_performance', 'vehicle_utilization', 'mileage'].includes(type)) {
        const fleet = await vehicles(req.query), activity = await records(req.query);
        rows = fleet.map((vehicle) => { const own = activity.filter((row) => row.vehicle_id === vehicle.id), trips = own.filter((row) => row.type === 'movement'), fuel = own.filter((row) => row.type === 'fuel'), distance = sum(trips, 'distance'), liters = sum(fuel, 'quantity'); return { ...vehicle, trips: trips.length, distance, fuel_liters: liters, efficiency: liters ? distance / liters : 0, operating_cost: sum(own, 'amount'), active_days: new Set(trips.map((row) => day(row.record_date))).size }; });
        columns = type === 'mileage' ? cols([['vehicle_id', 'Vehicle'], ['registration_number', 'Registration'], ['current_km', 'Current Odometer', 'number'], ['distance', 'Logged Trip KM', 'number'], ['trips', 'Trips', 'number']]) : cols([['vehicle_id', 'Vehicle'], ['registration_number', 'Registration'], ['assigned_driver', 'Driver'], ['trips', 'Trips', 'number'], ['active_days', 'Active Days', 'number'], ['distance', 'Distance KM', 'number'], ['fuel_liters', 'Fuel Liters', 'number'], ['efficiency', 'KM / Liter', 'number'], ['operating_cost', 'Operating Cost', 'money']]);
        summary = { vehicles: rows.length, totalTrips: sum(rows, 'trips'), totalDistance: sum(rows, 'distance'), totalAmount: sum(rows, 'operating_cost') };
    }
    else if (type === 'vehicle_cost') {
        const fleet = await vehicles(req.query), activity = await records(req.query);
        rows = fleet.map((vehicle) => { const operating_cost = sum(activity.filter((row) => row.vehicle_id === vehicle.id), 'amount'); return { ...vehicle, operating_cost, total_cost: Number(vehicle.purchase_price || 0) + operating_cost, cost_per_km: Number(vehicle.current_km) ? operating_cost / Number(vehicle.current_km) : 0 }; });
        columns = cols([['vehicle_id', 'Vehicle'], ['registration_number', 'Registration'], ['make', 'Make'], ['model', 'Model'], ['current_km', 'Current KM', 'number'], ['purchase_price', 'Purchase Price', 'money'], ['operating_cost', 'Operating Cost', 'money'], ['total_cost', 'Total Cost', 'money'], ['cost_per_km', 'Cost/KM', 'money']]);
        summary = { vehicles: rows.length, totalAmount: sum(rows, 'operating_cost'), fleetValue: sum(rows, 'purchase_price') };
    }
    else if (['fuel_daily', 'fuel_vehicle', 'fuel_cost', 'fuel_average', 'fuel_efficiency', 'fuel_monthly', 'fuel_abnormal', 'fuel_expense'].includes(type)) {
        const fuel = await records(req.query, ['fuel']), movement = await records(req.query, ['movement']);
        if (type === 'fuel_cost')
            rows = fuel;
        else if (type === 'fuel_daily')
            rows = [...group(fuel, row => day(row.record_date))].map(([record_date, list]) => ({ record_date, refills: list.length, quantity: sum(list, 'quantity'), amount: sum(list, 'amount') }));
        else if (type === 'fuel_monthly')
            rows = [...group(fuel, row => month(row.record_date))].map(([report_month, list]) => ({ report_month, refills: list.length, quantity: sum(list, 'quantity'), amount: sum(list, 'amount') }));
        else {
            const grouped = group(fuel, row => `${row.vehicle_id}`);
            rows = [...grouped].map(([, list]) => { const first = list[0], distance = sum(movement.filter((move) => move.vehicle_id === first.vehicle_id), 'distance'), liters = sum(list, 'quantity'), average = list.length ? liters / list.length : 0, efficiency = liters ? distance / liters : 0; return { vehicle_code: first.vehicle_code, registration_number: first.registration_number, refills: list.length, quantity: liters, average_quantity: average, distance, efficiency, amount: sum(list, 'amount') }; });
            if (type === 'fuel_abnormal') {
                const fleetAverage = rows.length ? sum(rows, 'average_quantity') / rows.length : 0;
                rows = rows.filter((row) => row.average_quantity > fleetAverage * 1.35 || row.efficiency > 0 && row.efficiency < 3).map((row) => ({ ...row, alert: row.average_quantity > fleetAverage * 1.35 ? 'High refill volume' : 'Low KM per liter' }));
            }
        }
        columns = type === 'fuel_daily' ? cols([['record_date', 'Date', 'date'], ['refills', 'Refills', 'number'], ['quantity', 'Liters', 'number'], ['amount', 'Fuel Cost', 'money']]) : type === 'fuel_monthly' ? cols([['report_month', 'Month'], ['refills', 'Refills', 'number'], ['quantity', 'Liters', 'number'], ['amount', 'Fuel Cost', 'money']]) : type === 'fuel_cost' ? standardColumns : cols([['vehicle_code', 'Vehicle'], ['registration_number', 'Registration'], ['refills', 'Refills', 'number'], ['quantity', 'Total Liters', 'number'], ['average_quantity', 'Average Refill', 'number'], ['distance', 'Trip KM', 'number'], ['efficiency', 'KM / Liter', 'number'], ['amount', 'Fuel Cost', 'money'], ...(type === 'fuel_abnormal' ? [['alert', 'Alert']] : [])]);
        summary = { records: rows.length, totalQuantity: sum(rows, 'quantity'), totalAmount: sum(rows, 'amount') };
    }
    else if (['service_due', 'upcoming_maintenance', 'maintenance_due', 'oil_due'].includes(type)) {
        const fleet = await vehicles(req.query), oil = type === 'oil_due';
        rows = fleet.filter((vehicle) => { const dueKm = oil ? vehicle.next_oil_change_km : vehicle.next_service_km, dueDate = oil ? vehicle.next_oil_change_date : vehicle.next_service_date; if (type === 'upcoming_maintenance')
            return dueDate && day(dueDate) >= today() && day(dueDate) <= soon(); return (dueKm && Number(vehicle.current_km) >= Number(dueKm)) || (dueDate && day(dueDate) <= soon()); }).map((vehicle) => ({ ...vehicle, due_km: oil ? vehicle.next_oil_change_km : vehicle.next_service_km, due_date: oil ? vehicle.next_oil_change_date : vehicle.next_service_date, alert: day(oil ? vehicle.next_oil_change_date : vehicle.next_service_date) < today() ? 'Overdue' : 'Due soon' }));
        columns = cols([['vehicle_id', 'Vehicle'], ['registration_number', 'Registration'], ['make', 'Make'], ['model', 'Model'], ['current_km', 'Current KM', 'number'], ['due_km', 'Due KM', 'number'], ['due_date', 'Due Date', 'date'], ['alert', 'Status']]);
        summary = { vehicles: rows.length, overdue: rows.filter((row) => row.alert === 'Overdue').length };
    }
    else if (['repair_cost', 'vehicle_maintenance_cost', 'spare_parts', 'workshop', 'maintenance_expense'].includes(type)) {
        const work = await records(req.query, ['repair', 'maintenance']);
        if (type === 'repair_cost')
            rows = work.filter((row) => row.type === 'repair');
        else if (type === 'spare_parts')
            rows = work.filter((row) => row.type === 'repair' && Number(row.parts_cost) > 0);
        else if (type === 'workshop')
            rows = [...group(work, row => row.vendor || 'Unspecified')].map(([vendor, list]) => ({ vendor, jobs: list.length, vehicles: new Set(list.map((row) => row.vehicle_id)).size, parts_cost: sum(list, 'parts_cost'), labour_cost: sum(list, 'labour_cost'), amount: sum(list, 'amount') }));
        else
            rows = [...group(work, row => `${row.vehicle_id}`)].map(([, list]) => ({ vehicle_code: list[0].vehicle_code, registration_number: list[0].registration_number, jobs: list.length, parts_cost: sum(list, 'parts_cost'), labour_cost: sum(list, 'labour_cost'), amount: sum(list, 'amount') }));
        columns = type === 'workshop' ? cols([['vendor', 'Workshop / Mechanic'], ['jobs', 'Jobs', 'number'], ['vehicles', 'Vehicles', 'number'], ['parts_cost', 'Parts', 'money'], ['labour_cost', 'Labour', 'money'], ['amount', 'Total', 'money']]) : type === 'spare_parts' ? cols([['record_date', 'Date', 'date'], ['vehicle_code', 'Vehicle'], ['title', 'Part / Work'], ['vendor', 'Supplier / Workshop'], ['parts_cost', 'Parts Cost', 'money'], ['amount', 'Total', 'money']]) : type === 'repair_cost' ? standardColumns : cols([['vehicle_code', 'Vehicle'], ['registration_number', 'Registration'], ['jobs', 'Jobs', 'number'], ['parts_cost', 'Parts', 'money'], ['labour_cost', 'Labour', 'money'], ['amount', 'Total', 'money']]);
        summary = { records: rows.length, totalAmount: sum(rows, 'amount'), partsCost: sum(rows, 'parts_cost'), labourCost: sum(rows, 'labour_cost') };
    }
    else if (['driver_list', 'driver_license_expiry'].includes(type)) {
        rows = await drivers(req.query);
        if (type === 'driver_license_expiry')
            rows = rows.filter((row) => row.license_expiry && day(row.license_expiry) <= soon(60)).map((row) => ({ ...row, alert: day(row.license_expiry) < today() ? 'Expired' : 'Due soon' }));
        columns = type === 'driver_list' ? driverColumns : cols([['name', 'Driver'], ['phone', 'Phone'], ['license_number', 'License'], ['license_expiry', 'License Expiry', 'date'], ['alert', 'Status']]);
        summary = { drivers: rows.length, active: rows.filter((row) => row.status === 'active').length, expired: rows.filter((row) => row.alert === 'Expired').length };
    }
    else if (['driver_attendance', 'driver_performance'].includes(type)) {
        const people = await drivers(req.query), trips = await records(req.query, ['movement']);
        rows = people.map((driver) => { const own = trips.filter((row) => row.driver_id === driver.id); return { ...driver, trips: own.length, attendance_days: new Set(own.map((row) => day(row.record_date))).size, total_km: sum(own, 'distance'), vehicles: new Set(own.map((row) => row.vehicle_id)).size }; });
        columns = cols([['name', 'Driver'], ['license_number', 'License'], ['status', 'Status'], ['attendance_days', 'Trip / Attendance Days', 'number'], ['trips', 'Trips', 'number'], ['vehicles', 'Vehicles Driven', 'number'], ['total_km', 'Total KM', 'number']]);
        summary = { drivers: rows.length, totalTrips: sum(rows, 'trips'), attendanceDays: sum(rows, 'attendance_days'), totalDistance: sum(rows, 'total_km') };
    }
    else if (['driver_salary', 'driver_fine', 'driver_expense'].includes(type)) {
        const expenses = await records(req.query, ['expense']);
        rows = expenses.filter((row) => row.driver_id && (type === 'driver_salary' ? /salary|wage/i.test(`${row.category} ${row.title}`) : type === 'driver_fine' ? /fine|penalty|challan/i.test(`${row.category} ${row.title}`) : true));
        columns = standardColumns;
        summary = summaryFor(rows);
    }
    else if (['daily_expense', 'vehicle_expense'].includes(type)) {
        const expenses = (await records(req.query)).filter((row) => ['fuel', 'repair', 'maintenance', 'oil_change', 'expense', 'goods'].includes(row.type) && !/revenue|income/i.test(`${row.category || ''} ${row.title || ''}`));
        if (type === 'daily_expense')
            rows = [...group(expenses, row => day(row.record_date))].map(([record_date, list]) => ({ record_date, transactions: list.length, amount: sum(list, 'amount') }));
        else
            rows = [...group(expenses, row => `${row.vehicle_id}`)].map(([, list]) => ({ vehicle_code: list[0].vehicle_code, registration_number: list[0].registration_number, transactions: list.length, amount: sum(list, 'amount') }));
        columns = type === 'daily_expense' ? cols([['record_date', 'Date', 'date'], ['transactions', 'Transactions', 'number'], ['amount', 'Total Expense', 'money']]) : cols([['vehicle_code', 'Vehicle'], ['registration_number', 'Registration'], ['transactions', 'Transactions', 'number'], ['amount', 'Total Expense', 'money']]);
        summary = { records: rows.length, totalAmount: sum(rows, 'amount') };
    }
    else if (type === 'dashboard_summary') {
        const fleet = await vehicles(req.query), people = await drivers(req.query), all = await records(req.query), todayRows = all.filter((row) => day(row.record_date) === today()), monthly = all.filter((row) => day(row.record_date) >= monthStart()), revenue = monthly.filter((row) => /revenue|income/i.test(`${row.category || ''} ${row.title || ''}`)), expenses = monthly.filter((row) => ['fuel', 'repair', 'maintenance', 'oil_change', 'expense', 'goods'].includes(row.type) && !revenue.includes(row));
        rows = [{ total_vehicles: fleet.length, active_vehicles: fleet.filter((row) => row.status === 'active').length, vehicles_on_trip: new Set(todayRows.filter((row) => row.type === 'movement').map((row) => row.vehicle_id)).size, under_maintenance: fleet.filter((row) => row.status === 'maintenance').length, total_drivers: people.length, today_trips: todayRows.filter((row) => row.type === 'movement').length, today_fuel_cost: sum(todayRows.filter((row) => row.type === 'fuel'), 'amount'), today_expenses: sum(todayRows.filter((row) => ['fuel', 'repair', 'maintenance', 'oil_change', 'expense', 'goods'].includes(row.type) && !/revenue|income/i.test(`${row.category || ''} ${row.title || ''}`)), 'amount'), monthly_revenue: sum(revenue, 'amount'), monthly_expenses: sum(expenses, 'amount'), net_profit_loss: sum(revenue, 'amount') - sum(expenses, 'amount') }];
        columns = cols([['total_vehicles', 'Total Vehicles', 'number'], ['active_vehicles', 'Active Vehicles', 'number'], ['vehicles_on_trip', 'Vehicles on Trip', 'number'], ['under_maintenance', 'Under Maintenance', 'number'], ['total_drivers', 'Total Drivers', 'number'], ['today_trips', "Today's Trips", 'number'], ['today_fuel_cost', "Today's Fuel Cost", 'money'], ['today_expenses', "Today's Expenses", 'money'], ['monthly_revenue', 'Monthly Revenue', 'money'], ['monthly_expenses', 'Monthly Expenses', 'money'], ['net_profit_loss', 'Net Profit / Loss', 'money']]);
        summary = rows[0];
    }
    else if (['registration_expiry', 'insurance_expiry', 'fitness_expiry', 'route_permit_expiry'].includes(type)) {
        const field = type === 'insurance_expiry' ? 'insurance_expiry' : type === 'fitness_expiry' ? 'fitness_expiry' : type === 'route_permit_expiry' ? 'route_permit_expiry' : null;
        if (field) {
            rows = (await vehicles(req.query)).filter((row) => row[field] && day(row[field]) <= soon(60)).map((row) => ({ ...row, expiry_date: row[field], alert: day(row[field]) < today() ? 'Expired' : 'Due soon' }));
        }
        else {
            let query = db('attachments as a').leftJoin('vehicles as v', 'v.id', 'a.vehicle_id').whereILike('a.document_type', '%Registration%').whereNotNull('a.expiry_date');
            if (req.query.vehicleId)
                query = query.where('a.vehicle_id', Number(req.query.vehicleId));
            if (req.query.from)
                query = query.where('a.expiry_date', '>=', String(req.query.from));
            if (req.query.to)
                query = query.where('a.expiry_date', '<=', String(req.query.to));
            rows = (await query.select('a.*', 'v.vehicle_id', 'v.registration_number')).map((row) => ({ ...row, alert: day(row.expiry_date) < today() ? 'Expired' : 'Due soon' }));
        }
        columns = cols([['vehicle_id', 'Vehicle'], ['registration_number', 'Registration'], ['make', 'Make'], ['model', 'Model'], ['expiry_date', 'Expiry Date', 'date'], ['alert', 'Status']]);
        summary = { vehicles: rows.length, expired: rows.filter((row) => row.alert === 'Expired').length };
    }
    else if (type === 'tyre_due') {
        rows = (await records(req.query)).filter((row) => /tyre|tire/i.test(`${row.category || ''} ${row.title || ''}`) && (row.next_due_date || row.next_due_km != null)).filter((row) => (row.next_due_date && day(row.next_due_date) <= soon(60)) || (row.next_due_km != null && Number(row.current_km || 0) >= Number(row.next_due_km)));
        columns = cols([['vehicle_code', 'Vehicle'], ['registration_number', 'Registration'], ['record_date', 'Last Tyre Record', 'date'], ['title', 'Tyre / Work'], ['odometer_km', 'Last KM', 'number'], ['next_due_km', 'Due KM', 'number'], ['next_due_date', 'Due Date', 'date']]);
        summary = { vehicles: rows.length };
    }
    else if (type === 'document_expiry') {
        let query = db('attachments as a').leftJoin('vehicles as v', 'v.id', 'a.vehicle_id').whereNotNull('a.expiry_date');
        if (req.query.vehicleId)
            query = query.where('a.vehicle_id', Number(req.query.vehicleId));
        if (req.query.from)
            query = query.where('a.expiry_date', '>=', String(req.query.from));
        if (req.query.to)
            query = query.where('a.expiry_date', '<=', String(req.query.to));
        rows = await query.select('a.id', 'a.document_type', 'a.original_name', 'a.expiry_date', 'a.created_at', 'v.vehicle_id as vehicle_code', 'v.registration_number').orderBy('a.expiry_date');
        rows = rows.map((row) => ({ ...row, status: day(row.expiry_date) < today() ? 'Expired' : 'Upcoming' }));
        columns = cols([['vehicle_code', 'Vehicle'], ['registration_number', 'Registration'], ['document_type', 'Document'], ['original_name', 'File'], ['expiry_date', 'Expiry Date', 'date'], ['status', 'Status']]);
        summary = { documents: rows.length, expired: rows.filter((row) => row.status === 'Expired').length };
    }
    else if (type === 'audit') {
        let query = db('audit_logs as a').leftJoin('users as u', 'u.id', 'a.user_id');
        if (req.query.from)
            query = query.where('a.created_at', '>=', String(req.query.from));
        if (req.query.to)
            query = query.where('a.created_at', '<=', `${String(req.query.to)} 23:59:59`);
        rows = await query.select('a.id', 'a.created_at', 'u.name as user_name', 'a.action', 'a.entity', 'a.entity_id', 'a.ip').orderBy('a.created_at', 'desc').limit(1000);
        columns = cols([['created_at', 'Date / Time', 'date'], ['user_name', 'User'], ['action', 'Action'], ['entity', 'Entity'], ['entity_id', 'Record ID'], ['ip', 'IP / Device']]);
        summary = { activities: rows.length, users: new Set(rows.map((row) => row.user_name).filter(Boolean)).size };
    }
    else
        return res.status(400).json({ error: 'Unknown report type.' });
    res.json({ type, title: labels[type], generatedAt: new Date().toISOString(), filters: req.query, columns, rows, summary });
}));
