import knex from 'knex';
import { config } from './config.js';

export const db = knex({
    client: 'pg',
    connection: { connectionString: config.databaseUrl, ssl: { rejectUnauthorized: false } },
    pool: { min: 0, max: 5 },
});

export async function pingDatabase() {
    await db.raw('select 1');
}
