import { db } from './db.js';

export const attachmentStore = {
    async put(name, bytes) {
        await db('attachment_blobs').insert({ stored_name: name, content: bytes });
    },
    async get(name) {
        const row = await db('attachment_blobs').where({ stored_name: name }).first('content');
        return row ? Buffer.from(row.content) : null;
    },
    async delete(name) {
        await db('attachment_blobs').where({ stored_name: name }).delete();
    },
};
