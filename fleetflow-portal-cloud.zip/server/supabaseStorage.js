const baseUrl = process.env.SUPABASE_URL?.replace(/\/$/, '');
const secretKey = process.env.SUPABASE_SECRET_KEY;
const legacyServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const serviceKey = secretKey || legacyServiceRoleKey;
const bucketName = process.env.SUPABASE_STORAGE_BUCKET || 'fleetflow-attachments';

function storageUrl(path = '') {
    if (!baseUrl || !serviceKey)
        throw new Error('Supabase Storage is not configured.');
    return `${baseUrl}/storage/v1${path}`;
}

function headers(extra = {}) {
    const result = { apikey: serviceKey, ...extra };
    // Supabase's new sb_secret_* keys are opaque API keys, not JWTs; sending
    // them as Bearer tokens causes Supabase to reject the request as an invalid JWT.
    if (!secretKey && legacyServiceRoleKey)
        result.authorization = `Bearer ${legacyServiceRoleKey}`;
    return result;
}

async function throwStorageError(response) {
    const message = (await response.text()).slice(0, 500);
    throw new Error(`Supabase Storage request failed (${response.status}): ${message}`);
}

export async function ensureAttachmentBucket() {
    const inspect = async () => fetch(storageUrl(`/bucket/${encodeURIComponent(bucketName)}`), { headers: headers() });
    const current = await inspect();
    if (current.ok) {
        const details = await current.json();
        if (details.public)
            throw new Error('The FleetFlow attachment bucket must remain private.');
        return;
    }
    if (current.status !== 404) await throwStorageError(current);
    const response = await fetch(storageUrl('/bucket'), {
        method: 'POST',
        headers: headers({ 'content-type': 'application/json' }),
        body: JSON.stringify({
            name: bucketName,
            public: false,
            file_size_limit: Number(process.env.MAX_UPLOAD_MB || 10) * 1024 * 1024,
            allowed_mime_types: ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'],
        }),
    });
    if (!response.ok) {
        const verify = await inspect();
        if (!verify.ok) await throwStorageError(response);
        const details = await verify.json();
        if (details.public) throw new Error('The FleetFlow attachment bucket must remain private.');
    }
}

export const attachmentStore = {
    async put(name, bytes, contentType) {
        const path = `/object/${encodeURIComponent(bucketName)}/${encodeURIComponent(name)}`;
        const response = await fetch(storageUrl(path), {
            method: 'POST',
            headers: headers({ 'content-type': contentType, 'x-upsert': 'false' }),
            body: bytes,
        });
        if (!response.ok) await throwStorageError(response);
    },
    async get(name) {
        const path = `/object/${encodeURIComponent(bucketName)}/${encodeURIComponent(name)}`;
        const response = await fetch(storageUrl(path), { headers: headers() });
        if (response.status === 404) return null;
        if (!response.ok) await throwStorageError(response);
        return Buffer.from(await response.arrayBuffer());
    },
    async delete(name) {
        const response = await fetch(storageUrl(`/object/${encodeURIComponent(bucketName)}`), {
            method: 'DELETE',
            headers: headers({ 'content-type': 'application/json' }),
            body: JSON.stringify({ prefixes: [name] }),
        });
        if (!response.ok) await throwStorageError(response);
    },
};
