import { z } from 'zod';
const emptyToNull = (v) => v === '' ? null : v;
const optionalNumber = z.preprocess(emptyToNull, z.coerce.number().nonnegative().nullable().optional());
const optionalDate = z.preprocess(emptyToNull, z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional());
export const loginSchema = z.object({ email: z.string().email(), password: z.string().min(8).max(200) });
export const vehicleSchema = z.object({
    vehicle_id: z.string().trim().min(2).max(80), registration_number: z.string().trim().min(2).max(80).regex(/^[A-Za-z0-9 -]+$/),
    make: z.string().trim().min(1).max(100), model: z.string().trim().min(1).max(100), variant: z.string().trim().max(100).optional().nullable(),
    model_year: optionalNumber, color: z.string().max(60).optional().nullable(), vehicle_type: z.string().max(60).optional().nullable(), fuel_type: z.string().max(40).optional().nullable(),
    transmission: z.string().max(40).optional().nullable(), engine_cc: optionalNumber, engine_number: z.string().max(120).optional().nullable(), vin: z.preprocess(emptyToNull, z.string().max(120).nullable().optional()),
    seating_capacity: optionalNumber, current_km: z.coerce.number().int().nonnegative(), assigned_driver_id: optionalNumber, status: z.enum(['active', 'inactive', 'maintenance', 'sold']), notes: z.string().max(3000).optional().nullable(),
    registration_date: optionalDate, registration_city: z.string().max(100).optional().nullable(), registration_owner: z.string().max(150).optional().nullable(), token_tax_expiry: optionalDate,
    insurance_company: z.string().max(150).optional().nullable(), insurance_policy_number: z.string().max(120).optional().nullable(), insurance_expiry: optionalDate, fitness_expiry: optionalDate, route_permit_expiry: optionalDate,
    purchase_date: optionalDate, dealer: z.string().max(150).optional().nullable(), purchase_price: optionalNumber, engine_oil_type: z.string().max(80).optional().nullable(), oil_capacity: optionalNumber,
    tyre_size: z.string().max(80).optional().nullable(), tyre_brand: z.string().max(100).optional().nullable(), last_service_km: optionalNumber, next_service_km: optionalNumber, next_service_date: optionalDate,
    last_oil_change_km: optionalNumber, next_oil_change_km: optionalNumber, next_oil_change_date: optionalDate,
});
export const recordSchema = z.object({
    type: z.enum(['fuel', 'movement', 'repair', 'maintenance', 'oil_change', 'expense', 'goods', 'document']), record_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    driver_id: optionalNumber, odometer_km: optionalNumber, quantity: optionalNumber, rate: optionalNumber, amount: z.coerce.number().nonnegative().default(0),
    parts_cost: optionalNumber, labour_cost: optionalNumber, start_km: optionalNumber, end_km: optionalNumber, category: z.string().max(80).optional().nullable(),
    title: z.string().trim().min(1).max(180), description: z.string().max(3000).optional().nullable(), vendor: z.string().max(180).optional().nullable(),
    location_from: z.string().max(180).optional().nullable(), location_to: z.string().max(180).optional().nullable(), reference_number: z.string().max(120).optional().nullable(),
    payment_method: z.string().max(60).optional().nullable(), next_due_km: optionalNumber, next_due_date: optionalDate, notes: z.string().max(3000).optional().nullable(),
}).superRefine((v, ctx) => {
    if (v.type === 'fuel' && (!v.quantity || v.quantity <= 0))
        ctx.addIssue({ code: 'custom', path: ['quantity'], message: 'Liters must be greater than zero.' });
    if (v.type === 'movement' && (v.start_km == null || v.end_km == null || v.end_km < v.start_km))
        ctx.addIssue({ code: 'custom', path: ['end_km'], message: 'End KM must be greater than or equal to Start KM.' });
});
