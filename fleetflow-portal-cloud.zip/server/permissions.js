import { db } from './db.js';
export const permissionCatalog = [
    ['view_dashboard', 'View dashboard'], ['view_vehicles', 'View vehicles'], ['create_vehicle', 'Add vehicles'], ['edit_vehicle', 'Edit vehicles'], ['delete_vehicle', 'Delete vehicles'],
    ['view_drivers', 'View drivers'], ['manage_drivers', 'Manage drivers'], ['view_records', 'View operational records'], ['manage_records', 'Add operational records'], ['delete_records', 'Delete operational records'],
    ['view_documents', 'View documents'], ['upload_documents', 'Upload documents'], ['delete_documents', 'Delete documents'], ['view_reports', 'View reports'], ['export_reports', 'Export reports'], ['print_reports', 'Print reports'],
    ['manage_users', 'Create and edit users'], ['manage_permissions', 'Manage role policies'], ['backup_restore', 'Backup and restore'], ['view_audit', 'View audit log'], ['manage_settings', 'Manage settings'],
];
export const roles = ['super_admin', 'admin', 'manager', 'accountant', 'fleet_manager', 'data_entry', 'viewer'];
const all = permissionCatalog.map(([key]) => key);
export const defaultRolePermissions = {
    super_admin: all,
    admin: all.filter(x => x !== 'manage_permissions'),
    manager: all.filter(x => !['manage_users', 'manage_permissions', 'backup_restore', 'delete_vehicle'].includes(x)),
    accountant: ['view_dashboard', 'view_vehicles', 'view_records', 'manage_records', 'view_documents', 'view_reports', 'export_reports', 'print_reports'],
    fleet_manager: ['view_dashboard', 'view_vehicles', 'create_vehicle', 'edit_vehicle', 'view_drivers', 'manage_drivers', 'view_records', 'manage_records', 'delete_records', 'view_documents', 'upload_documents', 'view_reports', 'export_reports', 'print_reports'],
    data_entry: ['view_dashboard', 'view_vehicles', 'create_vehicle', 'edit_vehicle', 'view_drivers', 'manage_drivers', 'view_records', 'manage_records', 'view_documents', 'upload_documents'],
    viewer: ['view_dashboard', 'view_vehicles', 'view_drivers', 'view_records', 'view_documents', 'view_reports', 'print_reports'],
};
export async function permissionsFor(userId, role) {
    if (role === 'super_admin')
        return [...all];
    const roleRows = await db('role_permissions').where({ role, allowed: true }).select('permission');
    const set = new Set(roleRows.map(x => x.permission));
    const overrides = await db('user_permissions').where({ user_id: userId }).select('permission', 'allowed');
    for (const row of overrides)
        row.allowed ? set.add(row.permission) : set.delete(row.permission);
    return [...set];
}
