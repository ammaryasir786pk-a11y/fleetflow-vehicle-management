import 'dotenv/config';
import path from 'node:path';
const root = path.resolve(process.env.APP_ROOT || process.cwd());
export const config = {
    appRoot: root,
    port: Number(process.env.PORT || 4000),
    nodeEnv: process.env.NODE_ENV || 'development',
    appUrl: process.env.APP_URL || 'http://localhost:5173',
    provider: process.env.DATABASE_PROVIDER === 'postgresql' ? 'postgresql' : 'sqlite',
    databaseUrl: process.env.DATABASE_URL || './data/fleet.db',
    jwtSecret: process.env.JWT_SECRET || 'development-only-secret-change-before-production',
    cookieSecure: process.env.COOKIE_SECURE === 'true',
    uploadDir: path.resolve(root, process.env.UPLOAD_DIR || './uploads'),
    maxUploadBytes: Number(process.env.MAX_UPLOAD_MB || 10) * 1024 * 1024,
};
if (config.nodeEnv === 'production' && config.jwtSecret.length < 32) {
    throw new Error('JWT_SECRET must contain at least 32 characters in production.');
}
if (config.nodeEnv === 'production' && !process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is required in production.');
}
