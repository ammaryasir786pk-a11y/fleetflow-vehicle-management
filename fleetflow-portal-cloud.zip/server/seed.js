import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
export async function seedDatabase(db) {
    const email = process.env.SEED_ADMIN_EMAIL || 'admin@fleetflow.local';
    if (!(await db('users').where({ email }).first()))
        await db('users').insert({
            name: 'System Administrator', email, password_hash: await bcrypt.hash(process.env.SEED_ADMIN_PASSWORD || crypto.randomBytes(18).toString('base64url'), 12), role: 'super_admin', active: true,
        });
    if (!(await db('drivers').first()))
        await db('drivers').insert([
            { name: 'Ahmed Khan', phone: '+92 300 1234567', license_number: 'FD-88321', license_expiry: '2027-05-30', status: 'active' },
            { name: 'Ali Raza', phone: '+92 301 7654321', license_number: 'FD-55719', license_expiry: '2026-12-15', status: 'active' },
        ]);
    if (!(await db('vehicles').first())) {
        const driver = await db('drivers').first();
        const ids = await db('vehicles').insert({ vehicle_id: 'HILUX-01', registration_number: 'ABC-123', make: 'Toyota', model: 'Hilux', variant: 'Revo', model_year: 2023, color: 'Super White', vehicle_type: 'Pickup', fuel_type: 'Diesel', transmission: 'Automatic', engine_cc: 2755, current_km: 128500, assigned_driver_id: driver.id, status: 'active', registration_city: 'Faisalabad', insurance_company: 'EFU', insurance_expiry: '2026-11-28', token_tax_expiry: '2026-10-15', next_service_km: 130000, next_service_date: '2026-09-15', next_oil_change_km: 130000, next_oil_change_date: '2026-09-15', purchase_price: 11200000 }).returning('id');
        const vehicleId = typeof ids[0] === 'object' ? ids[0].id : ids[0];
        const today = new Date();
        const iso = (days) => new Date(today.getTime() - days * 86400000).toISOString().slice(0, 10);
        await db('driver_assignments').insert({ vehicle_id: vehicleId, driver_id: driver.id, start_date: iso(120), status: 'active' });
        await db('records').insert([
            { vehicle_id: vehicleId, type: 'fuel', record_date: iso(1), driver_id: driver.id, odometer_km: 128500, quantity: 55, rate: 281, amount: 15455, vendor: 'PSO Canal Road', title: 'Diesel refill' },
            { vehicle_id: vehicleId, type: 'movement', record_date: iso(1), driver_id: driver.id, start_km: 128150, end_km: 128500, amount: 0, location_from: 'Faisalabad', location_to: 'Lahore', title: 'Purchased goods' },
            { vehicle_id: vehicleId, type: 'repair', record_date: iso(8), odometer_km: 127820, parts_cost: 15000, labour_cost: 6000, amount: 21000, vendor: 'City Auto Workshop', title: 'Brake pads', description: 'Front brake pads replaced' },
            { vehicle_id: vehicleId, type: 'oil_change', record_date: iso(15), odometer_km: 127000, quantity: 7, amount: 8500, category: 'Engine oil', title: 'Oil and filter', next_due_km: 132000, next_due_date: iso(-75) },
            { vehicle_id: vehicleId, type: 'maintenance', record_date: iso(22), odometer_km: 126500, amount: 12500, category: 'General Service', vendor: 'Toyota Faisalabad', title: 'Scheduled service' },
            { vehicle_id: vehicleId, type: 'expense', record_date: iso(25), amount: 5000, category: 'Other', vendor: 'Motorway', title: 'M-Tag recharge', payment_method: 'Bank' },
        ]);
    }
}
