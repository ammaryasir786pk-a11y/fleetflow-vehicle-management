import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db } from './db.js';
import { requirePermission } from './auth.js';
import { permissionCatalog, permissionsFor, roles } from './permissions.js';
export const adminRouter = Router();
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const userSchema = z.object({
    name: z.string().trim().min(2).max(120), email: z.string().email().transform(v => v.toLowerCase()), role: z.enum(['super_admin', 'admin', 'manager', 'accountant', 'fleet_manager', 'data_entry', 'viewer']),
    password: z.string().min(8).max(200).optional(), active: z.boolean().default(true), permissions: z.record(z.string(), z.boolean()).optional(),
});
async function audit(req, action, entityId, metadata) { await db('audit_logs').insert({ user_id: req.user?.id, action, entity: 'user', entity_id: entityId ? String(entityId) : null, ip: req.ip, metadata: metadata ? JSON.stringify(metadata) : null }); }
adminRouter.get('/policy-catalog', requirePermission('manage_users'), wrap(async (req, res) => {
    const roleRows = await db('role_permissions').where({ allowed: true }).select('role', 'permission');
    const policies = Object.fromEntries(roles.map(role => [role, roleRows.filter(x => x.role === role).map(x => x.permission)]));
    res.json({ permissions: permissionCatalog.map(([key, label]) => ({ key, label })), roles, policies });
}));
adminRouter.get('/users', requirePermission('manage_users'), wrap(async (_req, res) => {
    const users = await db('users').select('id', 'name', 'email', 'role', 'active', 'created_at', 'updated_at').orderBy('name');
    const result = [];
    for (const user of users)
        result.push({ ...user, permissions: await permissionsFor(user.id, user.role), overrides: await db('user_permissions').where({ user_id: user.id }).select('permission', 'allowed') });
    res.json(result);
}));
adminRouter.post('/users', requirePermission('manage_users'), wrap(async (req, res) => {
    const input = userSchema.parse(req.body);
    if (!input.password)
        return res.status(400).json({ error: 'Password is required for a new user.' });
    if (input.role === 'super_admin' && req.user?.role !== 'super_admin')
        return res.status(403).json({ error: 'Only Super Admin can create another Super Admin.' });
    const [row] = await db('users').insert({ name: input.name, email: input.email, password_hash: await bcrypt.hash(input.password, 12), role: input.role, active: input.active }).returning(['id', 'name', 'email', 'role', 'active']);
    if (input.permissions) {
        const roleAllowed = new Set(await permissionsFor(row.id, input.role));
        const overrides = Object.entries(input.permissions).filter(([key, value]) => roleAllowed.has(key) !== value).map(([permission, allowed]) => ({ user_id: row.id, permission, allowed }));
        if (overrides.length)
            await db('user_permissions').insert(overrides);
    }
    await audit(req, 'create_user', row.id, { role: row.role });
    res.status(201).json(row);
}));
adminRouter.put('/users/:id', requirePermission('manage_users'), wrap(async (req, res) => {
    const id = Number(req.params.id), input = userSchema.parse(req.body), before = await db('users').where({ id }).first();
    if (!before)
        return res.status(404).json({ error: 'User not found.' });
    if (before.role === 'super_admin' && req.user?.role !== 'super_admin')
        return res.status(403).json({ error: 'Only Super Admin can modify a Super Admin.' });
    if (id === req.user?.id && !input.active)
        return res.status(400).json({ error: 'You cannot deactivate your own account.' });
    const update = { name: input.name, email: input.email, role: input.role, active: input.active, updated_at: db.fn.now() };
    if (input.password)
        update.password_hash = await bcrypt.hash(input.password, 12);
    await db('users').where({ id }).update(update);
    await db('user_permissions').where({ user_id: id }).delete();
    if (input.permissions) {
        const roleRows = await db('role_permissions').where({ role: input.role, allowed: true }).select('permission');
        const roleAllowed = new Set(roleRows.map(x => x.permission));
        const overrides = Object.entries(input.permissions).filter(([key, value]) => roleAllowed.has(key) !== value).map(([permission, allowed]) => ({ user_id: id, permission, allowed }));
        if (overrides.length)
            await db('user_permissions').insert(overrides);
    }
    await audit(req, 'update_user', id, { before: { role: before.role, active: before.active }, after: { role: input.role, active: input.active } });
    res.json({ id, ...update, password_hash: undefined });
}));
adminRouter.put('/role-policies/:role', requirePermission('manage_permissions'), wrap(async (req, res) => {
    const role = req.params.role;
    if (!roles.includes(role) || role === 'super_admin')
        return res.status(400).json({ error: 'This role policy cannot be changed.' });
    const selected = z.array(z.string()).parse(req.body.permissions);
    await db('role_permissions').where({ role }).delete();
    if (selected.length)
        await db('role_permissions').insert(selected.map(permission => ({ role, permission, allowed: true })));
    await db('audit_logs').insert({ user_id: req.user?.id, action: 'update_role_policy', entity: 'role', entity_id: role, ip: req.ip, metadata: JSON.stringify({ permissions: selected }) });
    res.json({ role, permissions: selected });
}));
